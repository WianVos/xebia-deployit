Put your Deployit plugin extensions in this directory.
